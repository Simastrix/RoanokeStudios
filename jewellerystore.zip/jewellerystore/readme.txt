Thank you for purchasing the Jewellery Store for RedM, We hope you will enjoy what it has to offer.

You can find all the necessary files in the stream folder, we added the ytyp list in the fxmanifest.lua as well.
The Jewellery store location is marked in the PNG
teleport coordinates are as follows: 

enterPos = vector3(2656.732, -1280.76, 52.233),
enterSpawn = vector3(2657.238, -1280.97, 45.009),
exitPos = vector3(2657.238, -1280.97, 45.009),
exitSpawn = vector3(2656.732, -1280.76, 52.233),

Thank you again for supporting us. <3