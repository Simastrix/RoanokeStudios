Thank you for purchasing the piergazebo for RedM, We hope you will enjoy what it has to offer.

You can find all the necessary files in the stream folder and we've added the ytyp list in the fxmanifest.lua as well.
Put the files how you like them to be in your streaming setup. :)
The piergazebo has a version which stops rain as well and has been already setup in the YMAP.
Find the location of the wedding piergazebo in the attached PNG.

Thank you again for supporting us and have fun Ymapping. <3