Thank you for purchasing the large brickhouse for RedM, We hope you will enjoy what it has to offer.

You can find all the necessary files in the stream folder and we've added the ytyp list in the fxmanifest.lua as well.
Put the files how you like them to be in your streaming setup. :)
The props have inate weather protection.
Make sure to set your YMAP streaming extents larger than the original output with these new weather proof props.
Simply place other props in a big circle radius around your desired prop and use that streaming extents for you original YMAP.

Texture and object updates for this project will be free and can be asked for via our ticket system whenever we announce an update.

Thank you again for supporting us and have fun Ymapping. <3