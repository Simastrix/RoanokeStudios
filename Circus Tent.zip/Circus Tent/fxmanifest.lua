fx_version 'cerulean'
game 'rdr3'
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'

description 'Circus Tent by Cesca and Erwin'

--this_is_a_map 'yes'
lua54 'yes'

data_file 'DLC_ITYP_REQUEST' 'stream/circusexterior_ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/circusexteriorrain_ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/circusinterior_ytyp.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/circusparts_ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/net_ytyp.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/seating_ytyp'