Thank you for purchasing the Circus Tent for RedM, We hope you will enjoy what it has to offer.

You can find all the necessary files in the stream folder and we've added the ytyp list in the fxmanifest.lua as well.
Put the files how you like them to be in your streaming setup. :)
You can find the Circus Tent via PNG attached.

Thank you again for supporting us. <3