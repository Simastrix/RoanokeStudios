Thank you for purchasing the blackwater courthouse for RedM, We hope you will enjoy what it has to offer.

You can find all the necessary files in the stream folder and we've added the ytyp list in the fxmanifest.lua as well.
Put the files how you like them to be in your streaming setup. :)
You can find the blackwater courthouse via PNG attached.
teleport coords are as follows:
enterPos = vector3(-798.645, -1202.61, 44.193),
        enterSpawn = vector3(-756.639, -1174.74, 23.879),
        exitPos = vector3(-756.639, -1174.74, 23.879),
        exitSpawn = vector3(-798.645, -1202.61, 44.193),

Thank you again for supporting us. <3