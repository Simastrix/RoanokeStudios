Thank you for having interest in the ice cream deco pack for RedM, We hope you will enjoy what it has to offer.

Fun Fact, the Ice Cream wagon is my first ever 3d model I made.

You can find all the necessary files in the stream folder and we've added the ytyp list in the fxmanifest.lua as well.
If you want to edit the blank menu board, simply open the YTD file in OpenIV and replace the blank texture with your own menu.
The location of the wagon and outside café are marked in the PNG.

Thank you again for supporting us. <3