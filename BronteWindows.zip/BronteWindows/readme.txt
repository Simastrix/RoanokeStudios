Thank you for purchasing the Bulletproof Windows for the Angelo Bronte Mansion, We hope you will enjoy what it has to offer.

You can find all the necessary files in the stream folder and we've added the ytyp list in the fxmanifest.lua as well.
Put the files how you like them to be in your streaming setup. :)

Thank you again for supporting us and have fun blocking those intruders. <3