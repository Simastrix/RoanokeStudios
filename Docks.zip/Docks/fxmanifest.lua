fx_version 'cerulean'
game 'rdr3'
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'

description 'Docks by Cesca and Erwin'

--this_is_a_map 'yes'
lua54 'yes'

data_file 'DLC_ITYP_REQUEST' 'stream/bra_boathouse_ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/bra_boathousedock_ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/bra_boathousedockrain_ytyp.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/bra_boathouserain_ytyp.ytyp'