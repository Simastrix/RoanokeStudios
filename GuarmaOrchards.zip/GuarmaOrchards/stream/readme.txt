Thank you for purchasing the 3 orchards pack for RedM, We hope you will enjoy what it has to offer.

You can find all the necessary files in the stream folder, the tree xml's in the for objectloader folder and we've added the ytyp list in the fxmanifest.lua as well.
Put the files how you like them to be in your streaming setup. :)
You can find the orchards via PNG attached.

Thank you again for supporting us. <3