Thank you for purchasing the Guarma Orchard pack for RedM, We hope you will enjoy what it has to offer.

You can find all the necessary files in the stream folder, the XML's in the for objectloader folder and we've added the ytyp list in the fxmanifest.lua as well.
Make sure to read through the polyzone scripts first and adjust it to your needs. (original has qbqore linked, if you are on vorp change it to vorp)
You can also use your own pickable scripts, the ones in the polyzone folder are just for reference.
Additionally we provide 3 item icons you can use in your server item scripts.
You can find the 3 orchards via PNG attached.

Thank you again for supporting us. <3