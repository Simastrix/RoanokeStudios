Thank you for purchasing the strawberrycafe for RedM, We hope you will enjoy what it has to offer.

You can find all the necessary files in the stream folder and we've added the ytyp list in the fxmanifest.lua as well.
Put the files how you like them to be in your streaming setup. :)
The mainhouse and porch have versions which stop the rain as well and has been already setup in the YMAP.
Some minor rain still gets onto the porch, but that's because its obviously not fully roofed.

Thank you again for supporting us. <3